#include "cn_hw5.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    CN_HW5 w;
    w.show();

    return a.exec();
}
